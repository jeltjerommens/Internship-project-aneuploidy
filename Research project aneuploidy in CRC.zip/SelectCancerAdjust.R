#This code first opens the data. Then there is a function to choose a cancer type to analyze and then the data will be adjusted for analysis (correct for whole genome duplication)

setwd("~/Jaar 4 bachelor biologie/Scriptie en stage/Stage/Research project/data")

cnv <-read.table("Results_CopyNumber.tsv",header=TRUE,sep="\t", row.names = 1) 

cnv = t(cnv)

#This function looks for tumors from the given cancer type and returns it those in a new dataframe.The input is the cnv data of multiple cancer types and the cancer type you want to select for 

SelectCancerType = function(x, cancer){ 
  e = data.frame("")  
  for (i in 1:ncol(x)){   
    if (identical(x[1,i], cancer)) {  
      Sample = x[,i]      
      e = cbind(e, Sample)    
    }
  }
  e$X.. = NULL
  return(e)
}

#examples
cnv_lung = SelectCancerType(cnv, cancer = "Lung")
cnv_ova = SelectCancerType(cnv, cancer = "Ovary")
cnv_crc = SelectCancerType(cnv, cancer = "Colorectum")
cnv_breast = SelectCancerType(cnv, cancer = "Breast")


#Adjusting the data -> removing rows that are not going to be used, making the dataframe numeric and correcting for whole genome duplication. The input is cnv data. 

AdjustData = function(x){ 
  x = x[-1,]
  x = x[-1,]
  x = sapply(x[], as.numeric)
  chr_names = c('1p',	'1q',	'2p',	'2q',	'3p',	'3q',	'4p',	'4q',	'5p',	'5q',	'6p',	'6q',	'7p',	'7q',	'8p',	'8q',	'9p',	'9q',	'10p',	'10q',	'11p',	'11q',	'12p',	'12q',	'13q',	'14q',	'15q',	'16p'	, '16q'	, '17p',	'17q',	'18p',	'18q',	'19p',	'19q',	'20p',	'20q', '21q',	'22q',	'genome_level')
  row.names(x) = chr_names
  x = x[-40,]
  r = 0
  x = rbind(x, r)
  for (i in 1:ncol(x)){
    m = abs(mean(x[1:nrow(x),i]))
    x[40, i] = m
  }
  
  for (i in 1:ncol(x)){
    for (v in 1:nrow(x)){
      gl = x[v,i] - x["r", i]
      x[v,i] = gl
    }
  }
  
  x = x[-40,]
}

#examples
cnv_crc = AdjustData(cnv_crc)
cnv_lung = AdjustData(cnv_lung)
cnv_breast = AdjustData(cnv_breast)

