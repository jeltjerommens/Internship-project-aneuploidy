#This code is to make a heatmap of cnv data clustered on samples. Before the heatmap is made, some adjustments to the data are made. 


#In this code the new dataframe cnv_crc_ad is made. In this dataframe all values lower than -5 are set to -5 and values higher than 5 are set to 5. 
#All values between -1 and 1 are set to 0. These adjustments are made to make the heatmap more clear. 

cnv_crc_ad = cnv_crc

for (i in 1:nrow(cnv_crc_ad)){
  for (v in 1:ncol(cnv_crc_ad)){
    if (cnv_crc_ad[i,v] <= -5){
      cnv_crc_ad[i,v] = -5
    }
    if (cnv_crc_ad[i,v] > -1 & cnv_crc_ad[i,v] <= 1){
      cnv_crc_ad[i,v] = 0
    }
    
    if (cnv_crc_ad[i,v] >= 5){
      cnv_crc_ad[i,v] = 5
    }
    
  }
}


#This function makes the heatmap. First a hierarchical clustering is made of the samples based in the euclidean distances. 
#Then the heatmap is made with this clustering. The input is cnv data. 

make_heatmap = function(x){
  if (!"gplots" %in% installed.packages()){install.packages("gplots")}
  library(gplots)
  d1 = dist(t(x), method="euclidean", diag = F, upper = T)
  c1 = hclust(d1, method = "ward.D2", members=NULL)
  col = colorRampPalette(c("blue", "white", "red"))(20)
  heatmap.2(x, Colv=as.dendrogram(c1), Rowv=F,
            density.info = "density", trace= "none", col = col,
            cexRow=0.8, cexCol=0.75, dendrogram = "column")
}


#examples
make_heatmap(cnv_crc)
make_heatmap(cnv_crc_ad)
make_heatmap(cnv_breast)





