#This code looks at the co-occurrence of aneuploidies. The function SelectFreqChrom can be used to select only aneuploidies that occur in a certain percentage
#of the tumors, in this case 10%. It also adds a column with 1 for gain and -1 for loss that can later be used to see if a chromosome arm is frequently gained or lost.
#After that the function SelectChromViewpoint can be used to make two dataframes: One with a certain aneuploidy and one without. After this function
#is used, the gain_loss column with 1 or -1 needs to be added and/or renamed. 
#The function PercentOccur calculates in what percentage of samples each chromosome arm is gained/lost and adds that to a dataframe.
#The function MakeBarplot2 can be used to make a bar chart of two dataframe made with PercentOccur, one of the samples with the viewpoint and one without. 

SelectFreqChrom = function(cnv_crc){
  Gain = 0
  Loss = 0
  gain_loss = 0
  cnv_crc = cbind(cnv_crc, Gain)
  cnv_crc = cbind(cnv_crc, Loss)
  cnv_crc = cbind(cnv_crc, gain_loss)
  r=0
  t=0

  
  for (i in 1:nrow(cnv_crc)){  
    for (v in 1:ncol(cnv_crc)){   
      if(!is.na(cnv_crc[i,v])){    
        if (cnv_crc[i,v] >= 1){    
          t= t + 1}
        if (cnv_crc[i,v] <= -1){    
          r= r + 1
        }
      }
    }
    cnv_crc[i, "Gain"] = (t/(ncol(cnv_crc)-2)) * 100  
    cnv_crc[i, "Loss"] = (r/(ncol(cnv_crc)-2)) * 100 
    if (cnv_crc[i, "Gain"] > 10){
      cnv_crc[i, "gain_loss"] = 1 #gain
    }
    if (cnv_crc[i, "Loss"] > 10){
      cnv_crc[i, "gain_loss"] = -1 #loss
    }
    t=0  
    r=0
  }
  
  
  
  for (i in 1:nrow(cnv_crc)){   
    if (!(cnv_crc[i,"Gain"]>10 | cnv_crc[i,"Loss"]>10)){
      cnv_crc[i,] = NA
    }
  }
  
  cnv_crc = cnv_crc[rowSums(is.na(cnv_crc)) != ncol(cnv_crc), ]
  
  
  cnv_crc = cnv_crc[,-(ncol(cnv_crc)-2)]
  cnv_crc = cnv_crc[,-(ncol(cnv_crc)-1)]
}

#example
cnv_crc_freq = SelectFreqChrom(cnv_crc)


#selecting viewpoint and fixing the gain_loss column 

#7
cnv_crc_7 = SelectChromViewpoint(cnv_crc_freq, chromarm = "7p", chromarm2 = "7q", ploidy = "double gain")
cnv_crc_7_n = SelectChromViewpoint(cnv_crc_freq, chromarm = "7p", chromarm2 = "7q", ploidy = "double gain", aneuploidy = "without")
colnames(cnv_crc_7)[ncol(cnv_crc_7)] = "gain_loss"
cnv_crc_7_n[,(ncol(cnv_crc_7_n)+1)] = cnv_crc_freq[,ncol(cnv_crc_freq)]
colnames(cnv_crc_7_n)[ncol(cnv_crc_7_n)] = "gain_loss"

#13
cnv_crc_13 = SelectChromViewpoint(cnv_crc_freq, chromarm = "13q")
cnv_crc_13_n = SelectChromViewpoint(cnv_crc_freq, chromarm = "13q", aneuploidy = "without")
colnames(cnv_crc_13)[ncol(cnv_crc_13)] = "gain_loss"
cnv_crc_13_n[,(ncol(cnv_crc_13_n)+1)] = cnv_crc_freq[,ncol(cnv_crc_freq)]
colnames(cnv_crc_13_n)[ncol(cnv_crc_13_n)] = "gain_loss"

#20
cnv_crc_20 = SelectChromViewpoint(cnv_crc_freq, chromarm = "20p", chromarm2 = "20q", ploidy = "double gain")
cnv_crc_20_n = SelectChromViewpoint(cnv_crc_freq, chromarm = "20p", chromarm2 = "20q", ploidy = "double gain", aneuploidy = "without")
colnames(cnv_crc_20)[ncol(cnv_crc_20)] = "gain_loss"
cnv_crc_20_n[,(ncol(cnv_crc_20_n)+1)] = cnv_crc_freq[,ncol(cnv_crc_freq)]
colnames(cnv_crc_20_n)[ncol(cnv_crc_20_n)] = "gain_loss"

#18
cnv_crc_18 = SelectChromViewpoint(cnv_crc_freq, chromarm = "18p", chromarm2 = "18q", ploidy = "double loss")
cnv_crc_18_n = SelectChromViewpoint(cnv_crc_freq, chromarm = "18p", chromarm2 = "18q", ploidy = "double loss", aneuploidy = "without")
colnames(cnv_crc_18)[ncol(cnv_crc_18)] = "gain_loss"
cnv_crc_18_n[,(ncol(cnv_crc_18_n)+1)] = cnv_crc_freq[,ncol(cnv_crc_freq)]
colnames(cnv_crc_18_n)[ncol(cnv_crc_18_n)] = "gain_loss"


PercentOccur = function(x){
  t=0
  e = data.frame("")
  for (v in 1:nrow(x)){
    if (x[v,"gain_loss"] == 1){
      for (i in 1:(ncol(x)-1)){ 
        if (x[v,i] >= 1){ 
          t = t + 1 }
        }
      } 
    if (x[v,"gain_loss"] == -1){
      for (i in 1:(ncol(x)-1)){ 
        if (x[v,i] <= -1){ 
          t = t + 1 }
      }
    }
    p = round((t/ncol(x) * 100), 2)
    e = rbind(e, p)
    t = 0
    p = 0
  }
  return(e)
}


#7
e7 = PercentOccur(cnv_crc_7)
f7 = PercentOccur(cnv_crc_7_n)

#13
e13 = PercentOccur(cnv_crc_13)
f13 = PercentOccur(cnv_crc_13_n)

#20
e20 = PercentOccur(cnv_crc_20)
f20 = PercentOccur(cnv_crc_20_n)

#18
e18 = PercentOccur(cnv_crc_18)
f18 = PercentOccur(cnv_crc_18_n)


#function to make a barplot
MakeBarplot2 = function(e, f, color = c("red", "blue"), legend1 = "gain of 20", legend2 = "no gain of 20"){
  e = e[-1,]
  f = f[-1,]
  
  e = as.numeric(e)
  f = as.numeric(f)
  
  cond = rep(legend1, 23)
  cond1 = rep(legend2, 23)
  
  names = c("-1p", "+1q", "-3p", "-4p", "-4q", "+5p", "+6p", "+7p", "+7q", "-8p", "+8q", "+12p", "+13q", "-14q", "-15q", "+16p", "-17p", "-18p", "-18q", "+20p", "+20q", "-21q", "-22q")
  
  data1 = data.frame(names, cond, e)
  data2 = data.frame(names, cond1, f)
  
  colnames(data1) = c("name", "cond", "perc")
  colnames(data2) = c("name", "cond", "perc")
  
  data3 = rbind(data1, data2)
  
  data3$name = factor(data3$name, levels = names)
  data3$cond = factor(data3$cond, levels = c(legend2, legend1))
  
  
  if (!"ggplot2" %in% installed.packages()){install.packages("ggplot2")}
  library(ggplot2)
  
  ggplot(data3, aes(fill=cond, y=perc, x=name)) + 
    geom_bar(position="dodge", stat="identity") + scale_fill_manual(values= color) +
    labs(x="Aneuploidies", y = "Tumors(%)", fill = "") + scale_y_continuous(breaks=seq(0,100,10))
}

#examples
A = MakeBarplot2(e7, f7, color = c("plum1", "orchid3"), legend1 = "with gain of 7", legend2 = "without gain of 7")
B = MakeBarplot2(e13, f13, color = c("lightskyblue1", "cyan4"), legend1 = "with gain of 13", legend2 = "without gain of 13")
C = MakeBarplot2(e20, f20, color = c("darkolivegreen2", "chartreuse3"), legend1 = "with gain of 20", legend2 = "without gain of 20")
D = MakeBarplot2(e18, f18, color = c("darksalmon", "firebrick3"), legend1 = "with loss of 18", legend2 = "without loss of 18")

if(!require(devtools)) install.packages("devtools")
devtools::install_github("kassambara/ggpubr")

library(ggpubr)

ggarrange(A, B, C, D,  
          labels = c("A", "B", "C", "D"),
          ncol = 2, nrow = 2)








