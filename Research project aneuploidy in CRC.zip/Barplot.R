#This code can be used for making a barplot that displays if a chromosome arm is often gained, lost or neither. 

#This function makes a barplot. First is it calculated which percentage of the samples lost or gained a chromosome arm or neither. 
#A chromosome arm is gained when the relative copy number is above or is 1, lost when it is under or is -1 and everything in between is neutral.
#This information is then displayed in a barplot.The input is cnv data.

MakeBarplot = function(cnv_crc){
  Gain = 0
  Loss = 0
  Neutral = 0
  cnv_crc = cbind(cnv_crc, Gain)
  cnv_crc = cbind(cnv_crc, Loss)
  cnv_crc = cbind(cnv_crc, Neutral)
  g=0
  t=0
  h=0
  
  
  for (i in 1:nrow(cnv_crc)){  
    for (v in 1:(ncol(cnv_crc)-3)){   
      if(!is.na(cnv_crc[i,v])){    
        if (cnv_crc[i,v] >= 1){     
          t= t + 1}
        if (cnv_crc[i,v] <= -1){   
          g= g + 1
        }
        if (cnv_crc[i,v] > -1 & cnv_crc[i,v] < 1) {
          h = h + 1
        }
      }
    }
    cnv_crc[i, "Gain"] = (t/(ncol(cnv_crc)-3)) * 100  
    cnv_crc[i, "Loss"] = (g/(ncol(cnv_crc)-3)) * 100  
    cnv_crc[i, "Neutral"] = (h/(ncol(cnv_crc)-3)) * 100
    t=0  
    g=0
    h=0
  }
  
  
  cond = rep("Gain", nrow(cnv_crc))
  cond1 = rep("Neutral", nrow(cnv_crc))
  cond2 = rep("Loss", nrow(cnv_crc))
  
  #chrom =c( "1p" ,          "1q" ,          "2p" ,          "2q"   ,        "3p"     ,      "3q"      ,     "4p"      ,     "4q"    ,       "5p"       ,    "5q"     ,     
   #         "6p"      ,     "6q"     ,      "7p"     ,      "7q"      ,     "8p"      ,     "8q"       ,    "9p"       ,    "9q"      ,     "10p"     ,     "10q"    ,     
    #        "11p"    ,      "11q"    ,      "12p"     ,     "12q"      ,    "13q"      ,    "14q"     ,     "15q"     ,     "16p"     ,     "16q"    ,      "17p"   ,      
     #       "17q"     ,     "18p"     ,     "18q"     ,     "19p"      ,    "19q"      ,    "20p"     ,     "20q"      ,    "21q"      ,    "22q" )
  chrom = row.names(cnv_crc)
  
  data1 = data.frame(chrom, cond, cnv_crc[,"Gain"])
  data2 = data.frame(chrom, cond1, cnv_crc[,"Neutral"])
  data3 = data.frame(chrom, cond2, cnv_crc[,"Loss"])
  
  colnames(data1) = c("chrom", "cond", "gl")
  colnames(data2) = c("chrom", "cond", "gl")
  colnames(data3) = c("chrom", "cond", "gl")
  
  data4 = rbind(data1, data2, data3)
  
  
  
  
  data4$chrom = factor(data4$chrom, levels = chrom)
  data4$cond = factor(data4$cond, levels = c("Loss", "Neutral", "Gain"))
  
  if (!"ggplot2" %in% installed.packages()){install.packages("ggplot2")}
  library(ggplot2)
  
  
  ggplot(data4, aes(fill=cond, y=gl, x=chrom)) + 
    geom_bar(position="stack", stat="identity") + scale_fill_manual(values=c("cyan3", "lightcyan", "darkcyan")) +
    labs(title="Percentage of samples that gained/lost chromosome arm", 
         x="Chromsome arm", y = "Tumors(%)", fill = "") + scale_y_continuous(breaks=seq(0,100,10), sec.axis = sec_axis(~ 100 - ., breaks = seq(0,100,10)))
}

#examples 
MakeBarplot(cnv_crc)
MakeBarplot(cnv_lung)
MakeBarplot(cnv_crc_20q)



