#This code is to select a chromosome arm as a viewpoint, which means that only samples with that chromosome arm will be selected. 

#This function looks for samples with the given chromosome arm and returns the a dataframe with these samples. The input is cnv data and a chromosome arm you want to select.
#You can also indicate if you want to look at the gain or loss of the chromosome arm by changing the factor "ploidy" to "gain" or "loss".
#It is also possible to select the samples without the aneuploidy you're looking at. For this the factor "aneuploidy" can be changed to "wihtout". 

SelectChromViewpoint = function(x, chromarm, chromarm2, ploidy = "gain", aneuploidy = "with"){ 
  a = data.frame("")
  q = data.frame("")
  for (i in 1:ncol(x)){   
    if (ploidy == "gain"){
      if (x[chromarm,i] >= 1){
        Sample = x[,i]
        a = cbind(a, Sample)   
      }
      else {
        Sample = x[,i]
        q = cbind(q, Sample)
      }
    }
    if (ploidy == "loss"){
      if (x[chromarm,i] <= -1){
        Sample = x[,i]
        a = cbind(a, Sample)   
      }
      else {
        Sample = x[,i]
        q = cbind(q, Sample)
      }
    }
    if (ploidy == "double gain"){
      if (x[chromarm,i] >= 1 & x[chromarm2,i] >= 1){
        Sample = x[,i]
        a = cbind(a, Sample)
      }
      if (x[chromarm, i] < 1 & x[chromarm2,i] < 1) {
        Sample = x[,i]
        q = cbind(q, Sample)
      }
    }
    if (ploidy == "double loss"){
      if (x[chromarm,i] <= -1 & x[chromarm2,i] <= -1){
        Sample = x[,i]
        a = cbind(a, Sample)
      }
      if (x[chromarm, i] > -1 & x[chromarm2,i] > -1) {
        Sample = x[,i]
        q = cbind(q, Sample)
      }
    }
    
  }
  a = a[, -1]
  q = q[, -1]
  #chrom =c( "1p" ,          "1q" ,          "2p" ,          "2q"   ,        "3p"     ,      "3q"      ,     "4p"      ,     "4q"    ,       "5p"       ,    "5q"     ,     
  #          "6p"      ,     "6q"     ,      "7p"     ,      "7q"      ,     "8p"      ,     "8q"       ,    "9p"       ,    "9q"      ,     "10p"     ,     "10q"    ,     
  #          "11p"    ,      "11q"    ,      "12p"     ,     "12q"      ,    "13q"      ,    "14q"     ,     "15q"     ,     "16p"     ,     "16q"    ,      "17p"   ,      
  #           "17q"     ,     "18p"     ,     "18q"     ,     "19p"      ,    "19q"      ,    "20p"     ,     "20q"      ,    "21q"      ,    "22q" )
  chrom = row.names(x)
  row.names(a) = chrom
  row.names(q) = chrom
  if (aneuploidy == "with"){ 
    return(a)}
  if (aneuploidy == "without"){ 
    return(q)}
 
}

#examples 
cnv_crc_7p = SelectChromViewpoint(cnv_crc, chromarm = "7p")
cnv_crc_18q = SelectChromViewpoint(cnv_crc, chromarm = "18q", ploidy = "loss")
cnv_crc_20q = SelectChromViewpoint(cnv_crc, chromarm = "20q")
cnv_crc_20q_n = SelectChromViewpoint(cnv_crc, chromarm = "20q", aneuploidy = "without")
cnv_crc_20q_freq = SelectChromViewpoint(cnv_crc_freq, chromarm = "20q")
cnv_crc_7 = SelectChromViewpoint(cnv_crc_freq, chromarm = "7p", chromarm2 = "7q", ploidy = "double gain")
cnv_crc_7_n = SelectChromViewpoint(cnv_crc_freq, chromarm = "7p", chromarm2 = "7q", ploidy = "double gain", aneuploidy = "without")
cnv_crc_13 = SelectChromViewpoint(cnv_crc_freq, chromarm = "13q")
cnv_crc_13_n = SelectChromViewpoint(cnv_crc_freq, chromarm = "13q", aneuploidy = "without")
cnv_crc_20 = SelectChromViewpoint(cnv_crc_freq, chromarm = "20p", chromarm2 = "20q", ploidy = "double gain")
cnv_crc_20_n = SelectChromViewpoint(cnv_crc_freq, chromarm = "20p", chromarm2 = "20q", ploidy = "double gain", aneuploidy = "without")

